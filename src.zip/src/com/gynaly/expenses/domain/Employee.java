package com.gynaly.expenses.domain;

public class Employee {
    private int id;
    private String title;
    private String firstName;
    private String surname;
    private String jobTitle;
    private String departement;

    private ExpenseClaim[] claims;


    public Employee(){

    }

    public Employee(String title,String firstName, String surname){
        this.title = title;
        this.firstName = firstName;
        this.surname = surname;

    }

    public Employee(int id, String title, String firstName, String surname, String jobTitle, String departement) {
        this.id = id;
        this.title = title;
        this.firstName = firstName;
        this.surname = surname;
        this.jobTitle = jobTitle;
        this.departement = departement;
    }


    public String getMailingName(){
        return title + " "+ firstName + " " + surname;
    }
//   Mr. chandra vishwakram
//    Mr. C Vishwakarma
//    Mr. Vishwakrma

    public String getMailingName(boolean firstInitialOnly){

        if (firstInitialOnly){
            return title + " " + firstName.substring(0,1) + " " + surname;
        }else {
            return title + " " + surname;
        }
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if(firstName.length() < 2){
            System.out.println("Error - First Name Must be at least 2 Char");
        }else {
            this.firstName = firstName;
        }
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }
}
