package com.gynaly.expenses.domain;



public class Employees {

    private Employee[] employees;

    public Employees(int numberOfEmployees){
        employees = new Employee[numberOfEmployees];
    }

    public void addEmployee(Employee employee){
        int firstEmptyPositoin = -1;
        for (int i = 0; i < employees.length; i++) {
            if(firstEmptyPositoin == -1 && employees[i] == null){
                firstEmptyPositoin = i;
            }
        }
        if (firstEmptyPositoin == -1){
            System.out.println("Sorry the array is full");
        }else {
            employees[firstEmptyPositoin] = employee;
        }

    }

    public void printEmployee(){
        for(Employee e:employees){
            if(e != null){
                System.out.println(e.getMailingName());
            }
        }
    }

    public Employee findBySurname(String surname){
        for(Employee e : employees){
            if(e != null && e.getSurname().equals(surname)){
                return e;
            }
        }
        return null;
    }


}
