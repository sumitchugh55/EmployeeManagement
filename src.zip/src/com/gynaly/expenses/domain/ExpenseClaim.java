package com.gynaly.expenses.domain;

public class ExpenseClaim {

    private  Integer id;
    private  Integer employeeId;
    private  String dataOfClaim;
    private  Double totalAmount;
    private  Boolean approved;
    private  Boolean paid;

    public ExpenseClaim(Integer id, Integer employeeId, String dataOfClaim, Double totalAmount) {
        this.id = id;
        this.employeeId = employeeId;
        this.dataOfClaim = dataOfClaim;
        this.totalAmount = totalAmount;
        this.approved = false;
        this.paid = false;
    }

    public void setApproved(Boolean approved){
        this.approved = approved;
    }

    public void setPaid(Boolean paid){
        if(paid && !approved){
            System.out.println("This paymnet cannot be Done !");
        }else {
            this.paid = paid;
        }
    }

    public Integer getId() {
        return id;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public String getDataOfClaim() {
        return dataOfClaim;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public Boolean getApproved() {
        return approved;
    }

    public Boolean getPaid() {
        return paid;
    }
}
