package com.gynaly.expenses;

import com.gynaly.expenses.domain.Employee;
import com.gynaly.expenses.domain.Employees;
import com.gynaly.expenses.domain.ExpenseItem;

public class Main {
    public static void main(String[] args) {

        ExpenseItem expenseItem = new ExpenseItem(1234,12345678,"Hotel","To stay for the meeting",40.45);
        System.out.println(expenseItem.getDescription());

        Employee employee1 = new Employee("Mr.","Gyan","Vishwakarma");
        Employee employee2 = new Employee("Mr.","Akash","Abc");
        Employee employee3 = new Employee("Mr.","Vivek","Xyz");

        Employees employees = new Employees(15);

        employees.addEmployee(employee1);
        employees.addEmployee(employee2);
        employees.addEmployee(employee3);

        employees.printEmployee();
        Employee abc =  employees.findBySurname("hjgghj");
        System.out.println("Did Not find "+ (abc == null));

    }
}