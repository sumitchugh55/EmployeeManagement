import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class JavaLibraries {
    public static void main(String[] args) {
        Date today = new Date();

        GregorianCalendar calendar = new GregorianCalendar();
        calendar.set(Calendar.DAY_OF_MONTH,calendar.get(Calendar.DAY_OF_MONTH)-1);
        System.out.println(calendar.getTime());
        GregorianCalendar birthday = new GregorianCalendar(1952,3,16);
        Date birthdayDate =  birthday.getTime();
        System.out.println(today);
        System.out.println(birthdayDate);
        System.out.println(birthday);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String preetyDate = sdf.format(birthdayDate);
        System.out.println(preetyDate);

        LocalDateTime theDateAndTime = LocalDateTime.now();
        LocalDateTime otherDateAndTime = LocalDateTime.of(2022,11,16,17,23);
        System.out.println(theDateAndTime);
        System.out.println(otherDateAndTime);

        int i = 23;
        Integer i1 = i;

        Integer j = 45;
        int j1 = j;

    }
}
